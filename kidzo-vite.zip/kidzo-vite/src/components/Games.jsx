import React from 'react';
import Navbars2 from './Navbar2';
import Card_comp from './Card_comp';

function Games(){
    return (
        <>
            <Navbars2 />
        </>
    )
}
export default Games;