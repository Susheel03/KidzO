import React from 'react';

function Blank() {
  return (
    <div>
      <h1>This page is under development!</h1>
      {/* Add more content here if needed */}
    </div>
  );
}

export default Blank; 