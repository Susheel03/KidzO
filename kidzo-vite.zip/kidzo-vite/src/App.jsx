import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import signedincomp from './components/signedincomp';
import { SignedIn, SignedOut, SignInButton, UserButton } from "@clerk/clerk-react";


function App() {
  return (
    <header>
      <SignedOut>
        <SignInButton />
      </SignedOut>
      <SignedIn>
        <signedincomp />
      </SignedIn>
    </header>
  );
}
export default App;